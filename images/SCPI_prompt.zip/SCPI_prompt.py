# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 20:41:18 2019

@author: Chetan Sriram Madasu
Matriculation Number: G1800877A

"""

import pyvisa as v


def shell(instrument):
    while True:
        command = str(input('SCPI>>> '))
        if command == 'exit':
            break
        if command.find('?') > 0:
            try:
                response = instrument.query(command)
                print(response.strip())
            except v.VisaIOError:
                print('VisaIOError: Check the command!')
        else:
            instrument.write(command)
    return


rm = v.ResourceManager()
while True:
    resources = rm.list_resources()
    print('Press 0 to exit the shell.')
    for i, rcs in enumerate(resources):
        try:
            instrument = rm.open_resource(rcs)
            print('Press '+str(i+1)+' for '+instrument.query('*IDN?').strip())
        except v.VisaIOError:
            pass
    i = int(input())-1
    if i < 0:
        break
    instrument = rm.open_resource(resources[i])
    shell(instrument)
print('Type \'python SCPI_prompt.py\' to re-run the shell.')
